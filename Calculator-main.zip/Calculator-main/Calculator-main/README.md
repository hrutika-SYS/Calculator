
# calculator Web Application

Type: Individual Mini Project

Time: 1 Week

TechStack: HTML | CSS | JavaScript

Description: 
I have made this calcutator using the HTML, CSS, and JavaScript. It was an individual mini project.

### Live Link
[Checkout](https://gentle-dragon-7c373c.netlify.app)

### Calculator UI
![Screenshot 2022-11-04 193742](https://user-images.githubusercontent.com/76080960/199995189-c477a12d-45db-445e-a4a7-11c8d74f95c3.png)

